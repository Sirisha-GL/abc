package p;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;
import org.springframework.ui.Model;
@Controller
public class FController {
	@RequestMapping("/v1")
	public String show()
	{
		System.out.println("HELLO");
		return "First";
	}
	@RequestMapping("/v2")
	public String show2()
	{
		System.out.println("WELCOME");
		return "Second";
	}
}
