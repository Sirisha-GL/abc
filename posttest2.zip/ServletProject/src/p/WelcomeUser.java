package p;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class WelcomeUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection conn=null;
		String url="jdbc:mysql://localhost:3306/";
		String dbName= "db1";
		String driver="com.mysql.jdbc.Driver";
		String userName="root";
		String password="root";
	
		
		try {
			PrintWriter out=response.getWriter();
			 Class.forName(driver);
             conn= DriverManager.getConnection(url+dbName,userName,password);
             Statement sm=conn.createStatement();
			String s1=request.getParameter("click");
			if(s1.equals("update"))
			{
                out.println("<html><body>");
                out.println("<p>Please enter values to be updated</p>");
                out.println("<form name='ii' method='get' action='pass3'>");
	        	out.println("<P>ECODE <input type='text' value='' name='ecode'></P>");
	        	out.println("<P>ENAME <input type='text' value='' name='ename'></P>");
	        	out.println("<p><input type='submit' name='UPDATE'");
	        	out.println("</form></body></html>");
	        	String s=request.getParameter("ecode");
				String t= request.getParameter("ename");
				
             out.print("UPDATED");
            
             
             PreparedStatement ps= conn.prepareStatement("update emp set ename=? where ecode=?");
             ps.setString(1,t);
     		 ps.setString(2,s);
     		int x= ps.executeUpdate();
     		 conn.close();
             out.println("Disconnected from DataBase");
     				}
			else if(s1.equals("delete"))
			{
				 out.println("<html><body>");
	                out.println("<p>Please enter value to be deleted</p>");
	                out.println("<form name='ii' method='get' action='pass3'>");
		        	out.println("<P>ECODE <input type='text' value='' name='ecode'></P>");
		        	out.println("<p><input type='submit' name='DELETE'");
		        	out.println("</form></body></html>");
		        	String s=request.getParameter("ecode");
			
					
				out.print("DELETED");
				Class.forName(driver);
	             conn= DriverManager.getConnection(url+dbName,userName,password);
	             
	             PreparedStatement ps= conn.prepareStatement("delete from emp where ecode=?");
	     		 ps.setString(2,s);
	     		int y= ps.executeUpdate();
	     		 conn.close();
	             out.println("Disconnected from DataBase");
	     		 }
			else
			{
				 out.println("<html><body>");
	                out.println("<p>Please enter values to be inserted</p>");
	                out.println("<form name='ii' method='get' action='pass3'>");
		        	out.println("<P>ECODE <input type='text' value='' name='ecode'></P>");
		        	out.println("<P>ENAME <input type='text' value='' name='ename'></P>");
		        	out.println("<p><input type='submit' name='INSERT'");
		        	out.println("</form></body></html>");
		        	String s=request.getParameter("ecode");
					String t= request.getParameter("ename");
					
	            
		        PreparedStatement ps= conn.prepareStatement("insert into emp values(?,?)");
		        ps.setString(1,s1);
				ps.setString(2,s);
				int x= ps.executeUpdate();
			    conn.close();
		        out.println("Disconnected from DataBase");
	           
			}
		}
		catch(Exception e) {
	}

	
	}

}

