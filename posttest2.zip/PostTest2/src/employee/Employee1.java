package employee;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Employee1 extends HttpServlet {
	static int id=001;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			
			PrintWriter out = response.getWriter();
			Connection conn = getconnect.connect();
			Statement sm=conn.createStatement();
			ResultSet rs=sm.executeQuery("select * from employee");
			
				while(rs.next())
				{
					id++;
				}
				String s=request.getParameter("First_Name");
				String s1=request.getParameter("Last_Name");
				String s2=s.substring(0,2)+s1.substring(0,2)+id;
				String s3=request.getParameter("Address");
			PreparedStatement ps=conn.prepareStatement("insert into employee values(?,?,?,?)");
			ps.setString(1,s);
			ps.setString(2,s1);
			ps.setString(3,s2);
			ps.setString(4,s3);
			int x=ps.executeUpdate();
			System.out.println(x+" Record Inserted");
			conn.close();
			System.out.println("Disconnected from database");
		    } 
		catch (SQLException e)
			{
			e.printStackTrace();
		    }
		catch (IOException e)
			{
			e.printStackTrace();
			}
	}
		

}
