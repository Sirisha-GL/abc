package p1;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
@Controller
public class EditController 
{
	@Autowired
	EDao dao3;
	 @RequestMapping(value="/edit1/{ecode}")    
	    public String edit(@PathVariable String ecode, Model m){    
	        Emp emp=dao3.getEmpById(ecode);    
	        System.out.print("ecode="+emp.getEcode());
	        m.addAttribute("eobj",emp);  
	        System.out.println("in edit() ecode="+emp.getEname());
	        return "empeditform";    
	    }    
	    /* It updates model object. */    
	    @RequestMapping(value="/edit2",method= RequestMethod.POST)    
	    public String editsave(@ModelAttribute("emp") Emp emp)
	    {    System.out.println("in edit() ecode="+emp.ecode);
	        dao3.update(emp);    
	        return "redirect:/disDao";    
	    }    

}
