package p1;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;



@Controller
public class Controller1
{
	@Autowired
	EDao dao3;
	@RequestMapping(value="/disDao")
	public String disData(ModelMap m)
	{
	   List l=dao3.getEmployees();
	   m.addAttribute("lobj",l);
	   return "dis1";
		
	}

}
