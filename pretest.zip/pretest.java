import java.util.Scanner;
class revstrv{
public static void main(String args[])
{
int v=0;
Scanner word=new Scanner(System.in);
String a= word.nextLine();
String rev="";
for(int i=a.length()-1;i>=0;i++)
{
rev=rev+a.charAt(i);
}
System.out.println("Reverse string is:"+rev);
a=a.toLowerCase();
for(int j=0;j<a.length();j++)
{
char c=a.charAt(j);
if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u')
{
++v;
}
}
System.out.println("number of vowels:"+v);
}
}