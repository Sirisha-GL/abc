package p;
import java.util.*;

public class Question {
int id;
String q;
List<Answer> ans;
Question(int id, String q, List<Answer> ans)
{
	this.id=id;
	this.q=q;
	this.ans=ans;
}
void dis()
{
	System.out.println(id+" "+q+" ");
	Iterator itr=ans.iterator();
	System.out.println("ans are:");
	while(itr.hasNext())
	{
		System.out.println(itr.next());
	}
}
}
