package p;
import org.springframework.stereotype.*;
@Service
public class First {
public String SMsg()
{
	return "SEVICE MSG";
}
}
