package p;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
@Controller
@RequestMapping("/cl")
public class 	TController {
	@Autowired
	First f;

@RequestMapping(value="/ser",method=RequestMethod.GET)
public ModelAndView dis()
{
	return new ModelAndView("Hello" ,"msg",f.SMsg());
}
@RequestMapping(value="/ser1", method=RequestMethod.GET)
public ModelAndView dis1()
{
	return new ModelAndView("Hello 2" ,"msg",f.SMsg());
}
@RequestMapping(value="/ser2", method=RequestMethod.GET)
public ModelAndView dis2()
{
	return new ModelAndView("Hello 3" ,"msg",f.SMsg());
}
}
