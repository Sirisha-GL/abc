package p;


import org.springframework.beans.factory.BeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.beans.factory.xml.XmlBeanFactory;



public class StudentTest {
public static void main(String arg[])
{
	Resource resource=new ClassPathResource("applicationContext.xml");
	BeanFactory factory=new XmlBeanFactory(resource);
	Student student=(Student)factory.getBean("studentbean");
	student.displayInfo();
}
}
