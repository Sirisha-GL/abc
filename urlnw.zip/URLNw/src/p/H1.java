package p;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class H1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try
		{
			PrintWriter out=response.getWriter();
			String str=request.getParameter("name");
			String str1=request.getParameter("pswd");
			String s="Sirisha";
			String s1="sirisha";
			String s2="WE WELCOME YOU!";
			if((s.equals(str))&&(s1.equals(str1)))
			{
				out.print("<h1>VALID USER</h1>");
				out.print("<form method='get' action ='pass2'>");
				out.print("<input type='hidden' name='hid' value='"+s+"'>");
				out.print("<input type='hidden' name='hid1' value='"+s2+"'>");
				out.print("<br>");
				out.print("<input type='submit' value='continue' name='click'>");
				out.print("</form>");
			}
			else
			{
				out.print("login unsuccessfull");
			}
		}
			catch(Exception e)
		{}
		
				
				
			}
		}
