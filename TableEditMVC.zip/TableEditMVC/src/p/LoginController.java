 package p;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
@Controller
public class LoginController
{
	@Autowired
	LoginService ls;
	
	@RequestMapping(value="/add")//method = RequestMethod.POST)
	public String addData(ModelMap model)
	{
		
		Login lgn=new Login();
		
		model.addAttribute("lgobj",lgn);
	
		return "Welcome";
		
	}
	
		
	@RequestMapping(value="/save")//working
	public String addData2(@ModelAttribute("lgobj") Login lgobj1,ModelMap model)
	{
			
		model.addAttribute("lgobj",lgobj1);
		System.out.println("name="+lgobj1.getUname());
		ls.addLoginSer(lgobj1);
		return "redirect:/dis";                                                                                                                  //if we don't use redirect:/dis and simply write  return "DisRecord" then it's not working-exception
		
	}
	
	@RequestMapping(value="/dis")//working
	public String dis2(ModelMap model)
	{
			
		List al=ls.getData();
		model.addAttribute("lgobj",al);
		model.put("msg","ddd");
		return "DisRecord";
		
	}
	@RequestMapping(value="/edit1/{id}")
	public String editMethod(@PathVariable String id,ModelMap model)
	{
		List<Login> al=ls.edit2(id);
		model.addAttribute("lgobj",al);
		System.out.println("id in Ctrl="+id);
	
		
		return "Edit1";
	}
	@RequestMapping(value="/del/{id}",method = RequestMethod.GET)//working
	public String delMethod(@PathVariable String id,ModelMap model)
	{
		
		List<Login> al=ls.del(id);
		//model.addAttribute("lgobj",al);//not required
		return "redirect:/dis";
	}
}
