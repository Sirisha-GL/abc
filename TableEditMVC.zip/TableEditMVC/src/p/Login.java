package p;

public class Login 
{
	private String userId,uname, pwd;

	
	public Login() {
		super();
		
	}

	public Login(String userId, String uname, String pwd) {
		super();
		this.userId = userId;
		this.uname = uname;
		this.pwd = pwd;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

}
