class B
{
int c;
void add()
{
System.out.println("the sum:"+c);
}
}
class E
{
int a=10;
int e=12;

public static void main(String arg[])
{

E f=new E();
B b=new B();
b.c= f.a+f.e;
b.add();
}
}