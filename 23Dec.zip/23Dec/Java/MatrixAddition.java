class MatrixAddition{
int a[][]=new int[2][2];
int b[][]=new int[2][2];
int c[][]=new int[2][2];
int i,j;
public static void main(String arg[])
{
MatrixAddition m= new MatrixAddition();
m.a[0][0]=1;
m.a[0][1]=1;
m.a[1][0]=1;
m.a[1][1]=1;
m.b[0][0]=1;
m.b[0][1]=1;
m.b[1][0]=1;
m.b[1][1]=1;
for(m.i=0;m.i<2;m.i++)
{
	for(m.j=0;m.j<2;m.j++)
	{
		m.c[m.i][m.j]=m.a[m.i][m.j]+m.b[m.i][m.j];
		System.out.println(m.c[m.i][m.j]);
	}
}
}}
