class PassFail
{

public static void main(String arg[])
{
System.out.println("enter the marks of the students:");
int a=Integer.parseInt(arg[0]);
if (a<0&&a>100)
{
System.out.println("enter valid marks");
}
else if(a<=40)
{
System.out.println("FAIL");
}
else
{
System.out.println("PASS");
}
if(a>=90)
{
System.out.println("A");
}
else if((a<90)&&(a>=80))
{
System.out.println("B");
}
else if((a<80)&&(a>=70))
{
System.out.println("C");
}
else if ((a<70)&&(a>=60))
{
System.out.println("D");
}
else 
{
System.out.println("F");
}
}
}