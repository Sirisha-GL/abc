class PriNum{
public static void main(String arg[])
{
int i,j;
for(i=1;i<11;i++)
{
System.out.println(i);
}

for(i=10;i>0;i--)
{
	System.out.println(i);
}
for(i=0;i<20;i++)
{
	if(i%2==0)
	{
		System.out.println(i);
	}
}
for (i=0;i<3;i++)
{
	for(j=0;j<=i;j++)
	{
		System.out.print("*");
	}
	System.out.println(" ");
}
}
}