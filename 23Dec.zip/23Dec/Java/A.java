class D{
	int a,b;
	void display()
	{
		System.out.println("display");
	}
}
class C{
	int x;
	static int p=19;
	void show(){
		x=10;
		System.out.println("show()");
		System.out.println("x="+x);
	}
	public static void main(String arg[])
{
	System.out.println("hello!");
C c1=new C();
c1.show();
System.out.println("x in main method:"+c1.x);
	D d1= new D();
	d1.display();
	d1.a= Integer.parseInt(arg[0]);
	d1.b= Integer.parseInt(arg[1]);
	int z=d1.a+d1.b;
	System.out.println("z main:"+z);
	System.out.println("p static var is"+p);
}
}
