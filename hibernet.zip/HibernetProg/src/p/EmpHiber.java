package p;

import org.hibernate.Transaction;
import org.hibernate.*;
import org.hibernate.cfg.Configuration;

public class EmpHiber{
	
	public static void main(String Args[])
	{
		Configuration cfg=new Configuration();
		cfg.configure("hibernet.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session ses=sf.openSession();
		Transaction ts=ses.beginTransaction();
		ts.begin();
		Emp1 e1=new Emp1();
		e1.setId("4444");
		e1.setEcode("E73");
		e1.setEname("ppp");
		ses.persist(e1);
		System.out.println("success");
		ts.commit();
	}
	
}
