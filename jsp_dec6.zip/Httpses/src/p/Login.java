package p;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String un=request.getParameter("uname");
		String pwd=request.getParameter("pass");
		HttpSession s=request.getSession(true);
		if(un.equals("abc"))
		{
			out.println("WELCOME " +un);
			s.setAttribute("user ", un);
			out.println("<br> login page id=" +s.getId());
			out.println("<br>session Id");
			out.println(s.getId());
			
			
			out.println("<br>session Id");
			out.println(s.getId());
			out.println("<br>creation timer");
			out.println(new Date(s.getCreationTime()));
			out.println("<br>Last Access Time");
			out.println(new Date(s.getLastAccessedTime()));
			out.println("<br>Max inactive time interval(secs)");
			out.println(s.getMaxInactiveInterval());
			out.println("<br><a href='/Httpses/2>visit</a>");
		}
		else
		{
			RequestDispatcher id=request.getRequestDispatcher("index.html");
			out.println("<font color=red> EITHER USERNAME OR PASSWORD IS INCORRECT</font>");
			id.include(request, response);
		}
	}
			
		
}
		

