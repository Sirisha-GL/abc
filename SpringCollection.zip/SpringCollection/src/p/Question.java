package p;
import java.util.*;

public class Question {
int id;
String q;
List<Answer> ans;
public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getQ() {
	return q;
}

public void setQ(String q) {
	this.q = q;
}

public List<Answer> getAns() {
	return ans;
}

public void setAns(List<Answer> ans) {
	this.ans = ans;
}

public void dis()
{
	System.out.println(id+" "+q+" ");
	Iterator itr=ans.iterator();
	System.out.println("Courses are:");
	while(itr.hasNext())
	{
		System.out.println(itr.next());
	}
}
}
