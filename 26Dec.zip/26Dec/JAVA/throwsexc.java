class Division
{
	int x,y,z;
	void div() throws ArithmeticException
	{
		z=x/y;
		System.out.println("the value of z is:"+z);
	}

	public static void main(String a[])
	{
		Division D= new Division();
		D.x=1;
		D.y=0;
		System.out.println("Hello");
		D.div();
		
	
		System.out.println("Bye");
	
	}
}