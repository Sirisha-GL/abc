abstract class Abs
{
abstract void show();
}
class Subc1 extends Abs
{
/*void show()
{
System.out.println("class subc1");
}*/
public static void main(String ar[])
{
Subc1 b=new Subc1();
b.show();
Subc2 c =new Subc2();
c.show();
Subsub1 d= new Subsub1();
d.show();
}
}
class subc2 extends Abs
{
	void show()
	{
		System.out.println("class subc2");
		
	}
}
class Subsub1 extends B
{
	void show()
	{
		System.out.println("Class subsub1");
	}
}