class MyExcep extends Exception
{
	public String toString()
	{
		return "My value can't be divided by 7";
	}
}
class Exthrow
{
	void div()
	{
		int x,y,z;
		int p[]={2,3,4};
		x=110;
		y=7;
		try
		{
			if(y==7)
				throw new MyExcep();
			z=p[2]/y;
			System.out.println("z is"+z);
		}
		catch(ArithmeticException e)
		{
			MyExcep m= new MyExcep();
			m.toString();
			
		}
		finally
		{
			System.out.println("Finally");
		}
	}
	public static void main(String a[])
	{
		Exthrow E=new Exthrow();
		E.div();
	}
}