interface Parent
{
	public static final int x=10;
	public void m();
	default void method1()
	{
		System.out.println("This is the default method of Parent interface");
	}
	
}
interface Inf1
{
	int y=9;
	void display();
	void show();
	static void method2()
	{
		System.out.println("This is the static method of Inf1 interface");
	}
}
class Child implements Parent, Inf1
{
	public void show()
	{
		System.out.println("class Child");
	}
	public void display()
	{
		System.out.println("display Child");
	}
	public void m()
	{
		System.out.println("method m implemented x value is "+x);
	}
		 public static void main(String a[])
		 {
			 Child C=new Child();
			 C.show();
			 C.display();
			 C.m();
			 C.method1();
			 Inf1.method2();
		 }
}