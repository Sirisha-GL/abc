interface Parent
{
	public static final int x=10;
	public void m();
}
interface Inf1
{
	int y=9;
	void display();
	void show();
}
interface Inf2 extends Parent,Inf1
{
		void inf();
}
class Child implements Inf2
{
	public void show()
	{
		System.out.println("class Child");
	}
	public void display()
	{
		System.out.println("display Child the value of y is "+y);
	}
	public void m()
	{
		System.out.println("method m implemented x value is "+x);
	}
	public void inf()
	{
		System.out.println("Menthod inf implemented");
	}
		 public static void main(String a[])
		 {
			 Child C=new Child();
			 C.show();
			 C.display();
			 C.m();
			 C.inf();
		 }
}