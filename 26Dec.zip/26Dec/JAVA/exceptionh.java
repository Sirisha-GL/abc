class Division
{
	int x,y,z;
	void div()
	{
	
	try
	{
		z=x/y;
		System.out.println("the value of z is:"+z);
	}
	catch(ArithmeticException e)
	{
		System.out.println("The value of y can not be z");
	}
	}

	public static void main(String a[])
	{
		Division D= new Division();
		D.x=1;
		D.y=0;
		System.out.println("Hello");
		D.div();
		System.out.println("Bye");
	
	}
}
