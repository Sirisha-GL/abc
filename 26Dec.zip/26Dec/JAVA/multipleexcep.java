class Divi
{
	int x[];
	int y,z;
	void divis()
	{
		try
		{
			for(int i=0;i<2;i++)
			{
				z=x[i]/y;
				System.out.println("The value of z is:"+z);
			}
		}
		catch(ArithmeticException e)
		{
			System.out.println("The value of dividend can't be zero");
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("error");
		}
	}
	public static void main(String a[])
	{
		Divi D= new Divi();
		D.x[0]=1;
		D.x[1]=9;
		D.x[2]=10;
		D.y=0;
		System.out.println("Hello");
		D.divis();
		System.out.println("Bye");
	
	}
}