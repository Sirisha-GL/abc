class A1{
	int a;
	A1()
	{
	}
	A1(int a1)
	{
		a=a1;
	}
	}
	class A2  extends A1{
	int e;
	A2()
	{
	}
	A2(int a2)
	{
	super(40);
		e=a2;
	}
	}

class A3 extends A2{
	 int b;
	 A3(int c)
	 {
	 super(12);
	 b=c;
	 }
	 void show()
	 {
	 System.out.println("Class A3 b:"+b);
	 System.out.println("Class A2 e:"+e);
	 System.out.println("Class A1 a:"+a);
	 
	 }
	 public static void main(String ar[])
	 {
	 A3 A=new A3(55);
	 A.show();
	 }
}