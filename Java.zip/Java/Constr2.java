class Constr2
{
int x;
static int p;
Constr2(int x)
{
this.x=x;
}
Constr2()
{
x=20;
}
void show()
{
System.out.println("show");
System.out.println("x:"+x);
}
public static void main(String args[])
{
Constr2 C=new Constr2();
C.show();
Constr2 D=new Constr2(10);
D.show();
}
}