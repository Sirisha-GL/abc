class GrandParent
{
int x=11;
void show()
{
System.out.println("Class GrandParent");
}

}
class Parent extends GrandParent{
void show()
{
super.show();
System.out.println("Class Parent");
System.out.println("x:"+x);
}
}
class Child2 extends Parent{
void show()
{
super.show();
System.out.println("Class Child2");
System.out.println("x:"+x);
}
}
class Child1 extends GrandParent
{
void show()
{
super.show();
System.out.println("Class Child");
System.out.println("x:"+x);
}

public static void main(String arg[])
{
Child1 C=new Child1();
C.show();


}
}