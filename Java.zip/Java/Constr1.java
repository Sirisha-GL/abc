class Constr1
{
int x;
static int p;
Constr1(int x)
{
x=x;
}
Constr1()
{
x=20;
}
void show()
{
System.out.println("show");
System.out.println("x:"+x);
}
public static void main(String args[])
{
Constr1 C=new Constr1();
C.show();
Constr1 D=new Constr1(10);
D.show();
}
}