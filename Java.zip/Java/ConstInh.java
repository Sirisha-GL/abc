class A1{
	int a;
	A1()
	{
	}
	A1(int a1)
	{
		a=a1;
	}
	}
class A2 extends A1{
	 int b;
	 A2(int c)
	 {
	 super(12);
	 b=c;
	 }
	 void show()
	 {
	 System.out.println("Class A2 b:"+b);
	 System.out.println("Class A1 a:"+a);
	 }
	 public static void main(String ar[])
	 {
	 A2 A=new A2(55);
	 A.show();
	 }
}
