class A{
int p;
void show()
{
System.out.println("Class A p:"+p);
}
}
class B extends A{
int x;
void show()
{
super.show();
System.out.println("Class B x:"+x);
}
}
class C extends B
{
int y;
void show()
{
super.show();
System.out.println("Class C y:"+y);
}
public static void main(String args[])
{
A a=new B();
a.show();
A b= new C();
b.show();
}}