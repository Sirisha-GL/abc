class GrandParent
{
int x=11;
void show()
{
System.out.println("Class GrandParent");
}

}
class Parent extends GrandParent{
void show()
{
super.show();
System.out.println("Class Parent");
System.out.println("x:"+x);
}
}
class Child extends Parent
{
void show()
{
super.show();
System.out.println("Class Child");
System.out.println("x:"+x);
}

public static void main(String arg[])
{
Child C=new Child();
C.show();


}
}