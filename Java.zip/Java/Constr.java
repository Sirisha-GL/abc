class Constr
{
int x;
static int p;
Constr(int p)
{
x=p;
}
Constr()
{
x=20;
}
void show()
{
System.out.println("show");
System.out.println("x:"+x);
}
public static void main(String args[])
{
Constr C=new Constr();
C.show();
Constr D=new Constr(10);
D.show();
}
}
