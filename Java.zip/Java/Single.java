class Single
{
int x=11;
void show()
{
System.out.println("Class Single");
}
}
class C1 extends Single{
	
void show()
{
super.show();
System.out.println("Class C1");
System.out.println("x:"+x);
}
public static void main(String arg[])
{
C1 C=new C1();
C.show();

}
}