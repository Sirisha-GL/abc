package p;


import org.springframework.context.ApplicationContext;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class StudentTest {
public static void main(String arg[])
{
	ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
	Student st=(Student)context.getBean("e1");
	st.show();
}
}
