package p;

public class Student {
	private String name;
	private int id;

	
	public Student() {}
	public Student(String fn,int id)
	{
		this.id=id;
		this.name=fn;
	}
	public void show()
	{
		System.out.println(" "+id+" "+name);
	}
}
