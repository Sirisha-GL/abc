package p;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.*;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;


public class CutTag1 extends TagSupport {
	public int doStartTag() throws JspTagException
	{
	try
	{
		JspWriter out=pageContext.getOut();
		out.println("<br><b>Welcome custom tag</b></br>");
	}
	catch(Exception e)
	{}
		return SKIP_BODY;
	}
	
	public int doEndTag() throws JspTagException
	{
		return SKIP_PAGE;
		
	}
}