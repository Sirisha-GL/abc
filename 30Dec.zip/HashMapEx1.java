import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.*;
class Book
{
	int id;
	String name,publisher;
	int quantity;

	Book(int id, String name,int quantity)
	{
		this.id=id;
		this.name=name;
		this.quantity=quantity;
	}
}
public class HashMapEx1 {
public static void main(String ar[])
{
	Map<Integer,Book>hm=new HashMap<Integer, Book>();
	Book s2=new Book(2,"a",23);
	Book s3=new Book(3,"d",25);
	Book s4=new Book(4,"f",27);
	hm.put(1,s2);
	hm.put(2,s3);
	hm.put(3,s4);
	for(Map.Entry<Integer, Book> entry1:hm.entrySet())
	{
		int key=entry1.getKey();
		Book b=entry1.getValue();
		System.out.println(key+"Details: ");
		System.out.println(b.id+" "+b.name+" "+b.quantity);
	}
	HashMap hm1=new HashMap();
	Book s5=new Book(5,"a",22);
	Book s6=new Book(6,"d",21);
	Book s7=new Book(7,"f",20);
	hm1.put(1, s5);
	hm1.put(2, s6);
	hm1.put(3, s7);
	Set set= hm1.entrySet();
	Iterator i=set.iterator();
	System.out.println("With Iterator");
	while(i.hasNext())
	{
		Map.Entry me=(Map.Entry) i.next();
		Book bb=(Book)me.getValue();
		System.out.println(me.getKey());
		System.out.println(me.getKey()+":" );
		System.out.println(bb.id+ " "+bb.name+" "+bb.quantity);
	}
}
}
		
		
	
	
	