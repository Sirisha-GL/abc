
import java.util.*;

class BookH{
	int id;
	String name,author,publisher;
	int quantity;
	
	public BookH(int id, String name, String author, String publisher, int quantity)
	{
		this.id = id;
		this.name = name;
		this.author = author;
		this.publisher = publisher;
		this.quantity = quantity;
	}
}

public class HashMapEx2 {
	
	static void hashMapEx2()
	{
		Map<Integer,BookH> hm = new HashMap<Integer,BookH>();
		Scanner sc = new Scanner(System.in);
	
		System.out.println("How many entries do you want to enter? ");
		int n=sc.nextInt();
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter book id");
			int id = sc.nextInt();
			System.out.println("Enter book Name");
			String name = sc.next();
			System.out.println("Enter book author");
			String author = sc.next();
			System.out.println("Enter book publisher");
			String publisher = sc.next();
			System.out.println("Enter book quantity");
			int quantity = sc.nextInt();
			BookH b = new BookH(id,name,author,publisher,quantity);
			hm.put(1,b);
		}
		
		
		
		for(Map.Entry<Integer,BookH>entry1:hm.entrySet())
		{
			int key = entry1.getKey();
			BookH b = entry1.getValue();
			
			System.out.println(key+" Details: ");
			System.out.println(b.id+" "+b.name+" "+b.author+" "+b.publisher+" "+b.quantity);
		}
		
		
		
		
		Set set = hm.entrySet();
		
		Iterator itr = set.iterator();
		System.out.println("With Iterator");
		
		while(itr.hasNext())
		{
			Map.Entry me = (Map.Entry)itr.next();
			BookH bb = (BookH)me.getValue();
			
			System.out.println(me.getKey());
			System.out.println(bb.id+" "+bb.name+" "+bb.author+" "+bb.publisher+" "+bb.quantity);
		}
		System.out.println("End");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		hashMapEx2();
		
	}

}