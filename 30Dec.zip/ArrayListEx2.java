
import java.util.ArrayList;
import java.util.Iterator;
class Student
{
	int roll;
	String name;
	int age;
	Student(int roll, String name,int age)
	{
		this.roll=roll;
		this.name=name;
		this.age=age;
	}
}
public class ArrayListEx2 {
public static void main(String ar[])
{
	Student s1=new Student(1,"s",22);
	Student s2=new Student(2,"a",23);
	Student s3=new Student(3,"d",25);
	Student s4=new Student(4,"f",27);
	
	
	ArrayList<Student> al=new ArrayList<Student>();
	
	System.out.println("Initial size of the al is "+al.size());
	al.add(s1);
	al.add(s2);
	al.add(s3);
	al.add(s4);
	Iterator itr=al.iterator();
	System.out.println("Size of the arraylist after addition is:"+al.size());
	System.out.println("Contents of the array are:");
	while(itr.hasNext())
	{
		Student st=(Student)itr.next();
		System.out.println(st.roll+" "+st.name+" "+st.age);
		if(st.roll==2)
		{
			st.name="hhhh";
			
		}
	}
	Iterator itr1=al.iterator();
	
	
	System.out.println("Size of the arraylist after altering is:"+al.size());
	System.out.println("Contents of the array after are alterning:");
	while(itr1.hasNext())
	{
		Student st=(Student)itr1.next();
		System.out.println(st.roll+" "+st.name+" "+st.age);
	
	if(st.roll==2)
	{
		itr1.remove();
		
	}
	}
	Iterator itr2=al.iterator();
	System.out.println("Size of the arraylist after deletion is:"+al.size());
	System.out.println("Contents of the array after are deleting:");
	
	while(itr2.hasNext())
	{
		Student st=(Student)itr2.next();
		System.out.println(st.roll+" "+st.name+" "+st.age);
	}
	
	
	
}
}
