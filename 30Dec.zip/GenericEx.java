import java.util.ArrayList;

public class GenericEx {
	
	void show()
	{
		ArrayList a1  = new ArrayList();
		
		a1.add("pq");
		
		String s1 = (String) a1.get(0);
		System.out.println("a1= "+a1);
		ArrayList<String> list = new ArrayList<String>();
		list.add("abc");
		
		String s = list.get(0);
		System.out.println("s= "+s);
		
		ArrayList<Integer> list1 = new ArrayList<Integer>();
		list1.add(10);
		Integer s2 = list1.get(0);
		System.out.println("s2= "+s2);
	}

	public static void main(String[] args) {
		GenericEx g = new GenericEx();
		g.show();
		// TODO Auto-generated method stub
		
		
		
		
		

	}

}