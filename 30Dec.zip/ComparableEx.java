import java.util.*;
class Comp implements Comparable<Comp>
{
	int id;
	String name;
	Comp(int id, String name)
	{
		this.id=id;
		this.name=name;
		
	}
	public int compareTo(Comp c)
	{
		return name.compareTo(c.name);
		
	}
	public String toString()
	{
		return id+" "+name;
	}
}
class ComparableEx
{
	public static void main(String args[])
	{
		Comp c1=new Comp(900,"sirisha");
		Comp c2=new Comp(100,"alekhya");
		Comp c3=new Comp(200,"colony");
		List<Comp> s=new ArrayList<Comp>();
		s.add(c1);
		s.add(c2);
		s.add(c3);
		Collections.sort(s);
		System.out.println(s);
	}
}