import java.util.*;
class Comparat
{
	int id;
	String name;
	Comparat(int id, String name)
	{
		this.id=id;
		this.name=name;
		
	}
	public String toString()
	{
		return id+" "+name;
	}
}
class ComparatorEx implements Comparator<Comparat>
{
	public int compare(Comparat c1,Comparat c2)
	{
		if(c1.id==c2.id) 
			return 0;
		else if(c1.id>c2.id)
			return 1;
		else
			return -1;
	}
	public static void main(String args[])
	{
		Comparat c1=new Comparat(900,"sirisha");
		Comparat c2=new Comparat(100,"alekhya");
		Comparat c3=new Comparat(200,"colony");
		List<Comparat> s=new ArrayList<Comparat>();
		s.add(c1);
		s.add(c2);
		s.add(c3);
		Collections.sort(s,new ComparatorEx());
		System.out.println(s);
	}
}