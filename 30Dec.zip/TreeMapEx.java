import java.util.*;
public class TreeMapEx {

	public static void main(String[] args) {
		TreeMap <Integer,String> hm=new TreeMap<Integer,String>();
		hm.put(1, "Amit");
		hm.put(2, "Ravi");
		hm.put(3, "Vijay");
		hm.put(4, "Rahul");
		for(Map.Entry m:hm.entrySet())
			System.out.println(m.getKey()+ "  "+ m.getValue());
		
	}

}