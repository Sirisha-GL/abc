package com.example.demo.p;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
@Controller
public class FController {
	
	
	@RequestMapping("/l")
	public String showMsg()
	{
		System.out.println("First Boot!");
		return "First";
	}
	@RequestMapping("/pp")
	//public String second(@RequestParam("ename")String ename, @RequestParam("ecode")String ecode,ModelMap m)
	public String second(@RequestParam("ename") String ename,@RequestParam("ecode") String ecode,ModelMap m)
	{
	m.put("s1", ename);
	m.put("s2",ecode);
	System.out.println("First Boot!!");
	return "Second";
	}
}