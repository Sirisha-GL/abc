package com.example.JPAdemo.p;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.CollectionTable;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

@Entity
public class Users {

	@Id
	String uid;

	String pwd, name, address, phno, email;

	/*
	 * @ElementCollection
	 * 
	 * @CollectionTable(name="users_cart", joinColumns
	 * =@JoinColumn(name="users_uid"))
	 */
	/* List<Cart> cart; */

	public Users() {

	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhno() {
		return phno;
	}

	public void setPhno(String phno) {
		this.phno = phno;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	/*
	 * public List<Cart> getC() {
	 * System.out.println("in bean"+cart.iterator().next().getP_id()); return cart;
	 * }
	 * 
	 * public void setC(List<Cart> cart) { this.cart = cart; }
	 */
	/*
	 * public double calculate() { List l = this.cart; double total =0; Iterator it
	 * = l.iterator(); while(it.hasNext()) { total+= ((Cart) it.next()).cost; }
	 * return total; }
	 */
}
