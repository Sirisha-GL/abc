package com.example.JPAdemo.p;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Cart {

	@Id
	String p_id;
	String breed;
	
	 int age;
	 
	 
	 

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getBreed() {
		return breed;
	}

	public void setBreed(String breed) {
		this.breed = breed;
	}

	int cost;

	public Cart() {

	}

	public String getP_id() {
		return p_id;
	}

	public void setP_id(String p_id) {
		this.p_id = p_id;
	}

	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

	/*
	 * public String getUid() { return uid; }
	 * 
	 * public void setUid(String uid) { this.uid = uid; }
	 */
}
