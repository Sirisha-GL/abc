package com.example.JPAdemo.p1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.JPAdemo.p.Contact;
import com.example.JPAdemo.p.Pet;
import com.example.JPAdemo.p.PetService;
import com.example.JPAdemo.p.UserService;
import com.example.JPAdemo.p.Users;

@Controller
public class LogIn extends HttpServlet {

	@Autowired
	UserService us;
	@Autowired
	PetService ps;
	
	@RequestMapping("/lo")
	public String met() {
		return "index2";
	}
	
	@RequestMapping("/si")
	public String sign() {
		return "signin";
	}
	@RequestMapping("/k")
	public String sign1() {
		return "contacts";
	}
	@RequestMapping("/c")
	public String sign2() {
		return "cats";
	}
	@RequestMapping("/do")
	public String sign3() {
		return "dogs2";
	}

	@RequestMapping("/s")
	public String m(HttpServletRequest request, HttpServletResponse response, ModelMap m)
			throws ServletException, IOException {

		
		
		String un = request.getParameter("uname");
		String pwd = request.getParameter("pwd");
		HttpSession ses = request.getSession(true);
	
		if(un.equals("admin")&&pwd.equals("admin")) {
			return "ADMIN";
		}
		
		List<Users> lu = us.listAll();
		Iterator it = lu.iterator();
		List<String> u = new ArrayList<>();
		List<String> p = new ArrayList<>();
		Users user;
		while(it.hasNext()) {
			 user = (Users) it.next();
			
			u.add(user.getUid());
			p.add(user.getPwd());
		}
		
		if(u.indexOf(un)==p.indexOf(pwd)) {
			m.addAttribute("usr",un);
			ses.setAttribute("usr", un);
			return "home";
		}
		else {
			return "invalid";
		}
	}
	
	@RequestMapping("/vu")
	public String viewAllUsers(Model m) {
		List<Users> l = us.listAll();
		m.addAttribute("uobj",l);
		return "ViewAllUsers"; 
	}
	
	@RequestMapping("/vp")
	public String viewAllPets(Model m) {
		List<Pet> p = ps.listAll();
		m.addAttribute("pobj",p);
		return "viewAllPets";
	}
	
	@RequestMapping("/t")
	public String x(HttpSession ses, ModelMap m) {
		String s = (String) ses.getAttribute("user");
		m.addAttribute("user", s);
		return "second";
	}
	
	

	

}
