package com.example.JPAdemo.p;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Pet {

	@Id
	String pid;
	
	String breed; int age; int cost;

	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

	public String getBreed() {
		return breed;
	}

	public void setBreed(String breed) {
		this.breed = breed;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

}
