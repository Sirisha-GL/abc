package com.example.JPAdemo.p1;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.JPAdemo.p.UserService;
import com.example.JPAdemo.p.Users;

@Controller
public class SignUp {

	@Autowired
	UserService us;

	@RequestMapping(value = "/newuser")
	public String showNewUserPage(Model model) {
		Users user = new Users();
		model.addAttribute("uobj", user);

		return "NewUser";
	}

	@RequestMapping(value = "/saveuser", method = RequestMethod.POST)
	public String saveNewContact(@ModelAttribute("uobj") Users uobj) {
		List<Users> lu = us.listAll();
		Iterator it = lu.iterator();
		List<String> u = new ArrayList<>();
		Users user;
		while (it.hasNext()) {
			user = (Users) it.next();
			u.add(user.getUid());
		}

		if (u.indexOf(uobj.getUid()) != -1) {
			return "fourth";
		} else {
			us.saveUsers(uobj);
			return "third";
		}
	}
}
