package com.example.JPAdemo.p1;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.JPAdemo.p.Cart;
import com.example.JPAdemo.p.CartRepository;
import com.example.JPAdemo.p.Pet;
import com.example.JPAdemo.p.PetRepository;
@Controller
public class CartController {

	@Autowired 
	CartRepository cr;
	
	@Autowired
	PetRepository pr;
	
	@RequestMapping(value="/rfc/{p_id}") 
	public String rfc(@PathVariable(name="p_id") String id, Model m)
	{
		Pet p = new Pet();
		p.setPid(id); p.setAge(cr.findById(id).get().getAge()); p.setBreed(cr.findById(id).get().getBreed()); 
		p.setCost(cr.findById(id).get().getCost());
		cr.deleteById(id);
		pr.save(p);
		List<Cart> crt = cr.findAll();
		m.addAttribute("userCart",crt);
		Iterator it = crt.iterator();
		int sum=0;
		while(it.hasNext()) {
			sum+=((Cart)it.next()).getCost();
		}
		System.out.println(sum);
		m.addAttribute("Amt", sum);
		return "AddedToCart";
	}
	
	@RequestMapping("/ref")
	public String refresh(Model m) {
	return "cart";	
	}
	
	@RequestMapping("/thank")
	public String refresh1(Model m) {
	return "Thankyou";	
	}
	
	@RequestMapping("/log")
	public String ref1(Model m) {
	cr.deleteAll();
	return "index2";	
	}
}
