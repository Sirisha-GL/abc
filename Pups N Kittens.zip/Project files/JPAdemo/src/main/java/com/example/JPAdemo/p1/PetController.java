package com.example.JPAdemo.p1;

import com.example.JPAdemo.p.Cart;
import com.example.JPAdemo.p.CartRepository;
import com.example.JPAdemo.p.Contact;
import com.example.JPAdemo.p.Pet;
import com.example.JPAdemo.p.PetService;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.criteria.CriteriaQuery;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.JPAdemo.p.UserService;
import com.example.JPAdemo.p.Users;

@Controller
public class PetController {

	@Autowired
	PetService ps;

	@Autowired
	UserService us;

	@RequestMapping("/d")
	public String dog() {
		return "Dogs";
	}
	
	@Autowired
	CartRepository cr;

	@RequestMapping("/pt")
	public String searchBreed(@RequestParam("breed") String breed, Model m) {

		List<Pet> p = ps.listBreed(breed);
		m.addAttribute("lstPet", p);
		return "view";
	}

	@RequestMapping(value="/cart/{pid}")
	public String addedToCart(@PathVariable(name="pid") String id, HttpServletRequest request,Model m)
	{
		Pet p = ps.getId(id);
		HttpSession ses = request.getSession(false);
		String uid = (String) ses.getAttribute("usr");
		Users user = us.getId(uid);
		Cart c = new Cart();
		c.setP_id(id); c.setCost(p.getCost()); c.setBreed(p.getBreed()); c.setAge(p.getAge());
		cr.save(c);
		ps.deletePet(id);
		/*System.out.println(user.getName());
		List<Cart> crt = user.getC();
		crt.add(c);
		user.setC(crt);
		//us.saveUsers(user);
		//System.out.println("in cart"+user.getC().iterator().next().getP_id());*/
		List<Cart> crt = cr.findAll();
		m.addAttribute("userCart",crt);
		Iterator it = crt.iterator();
		int sum=0;
		while(it.hasNext()) {
			sum+=((Cart)it.next()).getCost();
		}
		System.out.println(sum);
		m.addAttribute("Amt", sum);
		return "AddedToCart";
	}
	
	@RequestMapping(value="/re/{pid}")
	public String remove(@PathVariable(name="pid")String pid) {
		ps.deletePet(pid);
		return "redirect:/vp";
	}
	
	@RequestMapping(value="/newPet")
	public String addPet(ModelMap m) {
	Pet p = new Pet();
	m.addAttribute("pobj",p);
	return "NewPet";
	}
	
	@RequestMapping(value="/savePet")
	public String savePet(@ModelAttribute("pobj") Pet pobj) {
		ps.savePet(pobj);
		return "redirect:/vp";
	}
	
	/*@RequestMapping(value="/rfc/{id}")
	public String rfc(@PathVariable(name="id")String id, Model m)
	{
		cr.deleteById(id);
		List<Cart> crt = cr.findAll();
		m.addAttribute("userCart",crt);
		Iterator it = crt.iterator();
		int sum=0;
		while(it.hasNext()) {
			sum+=((Cart)it.next()).getCost();
		}
		System.out.println(sum);
		m.addAttribute("Amt", sum);
		return "AddedToCart";

	}*/
	
}
