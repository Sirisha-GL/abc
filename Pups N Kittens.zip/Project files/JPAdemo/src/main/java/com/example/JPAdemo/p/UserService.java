package com.example.JPAdemo.p;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

	@Autowired
	UserRepository ur;
	
	UserService(){
		
	}

	public List<Users> listAll() {
		return  ur.findAll();
	}

	public Users getId(String id) {
		return ur.findById(id).get();
	}

	public void saveUsers(Users u) {
		ur.save(u);
	}

	public void deleteUsers(String id) {
		ur.deleteById(id);
	}
}
