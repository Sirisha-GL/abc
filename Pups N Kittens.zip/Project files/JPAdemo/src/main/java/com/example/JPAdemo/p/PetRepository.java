package com.example.JPAdemo.p;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PetRepository extends JpaRepository<Pet, String> {

	public List<Pet> findByBreed(String breed);
}
