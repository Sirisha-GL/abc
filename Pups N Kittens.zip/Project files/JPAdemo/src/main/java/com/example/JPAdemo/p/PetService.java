package com.example.JPAdemo.p;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PetService {

	@Autowired
	PetRepository pt;
	
	PetService(){
		
	}

	public List<Pet> listAll() {
	return  pt.findAll();
	}
	
	public List<Pet> listBreed(String breed){
		return pt.findByBreed(breed);
	}

	public Pet getId(String id) {
		return pt.findById(id).get();
	}

	public void savePet(Pet u) {
		pt.save(u);
	}

	public void deletePet(String id) {
		pt.deleteById(id);
	}
}
