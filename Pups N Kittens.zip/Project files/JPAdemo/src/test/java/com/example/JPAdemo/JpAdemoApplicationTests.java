package com.example.JPAdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpAdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
