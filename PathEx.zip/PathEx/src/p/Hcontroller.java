package p;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
@Controller
@RequestMapping("/cl")
public class Hcontroller {
@Autowired
First f;
@RequestMapping(value="/ser", method=RequestMethod.GET)
public ModelAndView dis()
{
	return new ModelAndView("Hello" ,"msg", f.SMsg());
}
}
