package orac;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;
public class inso {
	
	 public static void main(String ar[]) 
	 
		{
			System.out.println("sjjj");
			System.out.println("........... Oracle JDBC Connection Testing...............");
			Connection connection=null;
			Scanner scan=new Scanner(System.in);
			try
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
				connection= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
				System.out.println("Connected");
				PreparedStatement ps= connection.prepareStatement("insert into tab values(?,?)");
				ps.setString(1,scan.next());
				ps.setString(2, scan.next());

				int x=ps.executeUpdate();
				System.out.println(""+x+"record inserted");
				connection.close();
				System.out.println("disconnected fro db");
				}
			catch(Exception e)
			{
				System.out.println("connection fail");
				e.printStackTrace();
				
			}
			
			
			}
	}


