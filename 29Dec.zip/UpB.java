package pp;
import java.sql.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Scanner;

public class UpB {
void show()
{
	Scanner scan= new Scanner(System.in);
	System.out.println("MySQL Connect Example");
	Connection conn=null;
	String url="jdbc:mysql://localhost:3306/";
	String dbName= "db2";
	String driver="com.mysql.jdbc.Driver";
	String userName="root";
	String password="root";
	try
	{
		Class.forName(driver);
		conn=DriverManager.getConnection(url+dbName,userName,password);
		PreparedStatement ps= conn.prepareStatement("update emp3 set ename=? where ecode=?");
		//String s1="tt";
		conn.setAutoCommit(false);
		//String s="e001";
		//ResultSet rs=sm.executeQuery("select * from emp3 where ecode is '"+s+"' and ename is '"+s1+"'");
		ps.setString(1,scan.next());
		ps.setString(2, scan.next());
		ps.addBatch();
		int y[]=ps.executeBatch();
		for(int i:y)
		{
			System.out.println(""+i);
			conn.commit();
		}
		conn.close();
		System.out.println("disconnected fro db");
		}
	catch(Exception e)
	{
		e.printStackTrace();
				
		
	}
}
	public static void main(String a[])
	{
		UpB s1=new UpB();
		s1.show();
		
	}

}