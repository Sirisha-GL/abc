package pp;
import java.sql.*;
import java.sql.Connection;
import java.sql.ResultSet;

public class Sel1 {
void show()
{
	System.out.println("MySQL Connect Example");
	Connection conn=null;
	String url="jdbc:mysql://localhost:3306/";
			String dbName= "db1";
	String driver="com.mysql.jdbc.Driver";
	String userName="root";
	String password="root";
	try
	{
		Class.forName(driver);
		conn=DriverManager.getConnection(url+dbName,userName,password);
		Statement sm=conn.createStatement();
		
		String s1="tt";
		String s="e001";
		//ResultSet rs=sm.executeQuery("select * from emp3 where ecode is '"+s+"' and ename is '"+s1+"'");
		
		ResultSet rs=sm.executeQuery("select * from emp3");
		System.out.println("connected to the db");
		while(rs.next())
		{
			String f=rs.getString(1);
			String f1=rs.getString(2);
			System.out.println(f);
			System.out.println(f1);
		}
		conn.close();
		System.out.println("disconnected fro db");
		}
	catch(Exception e)
	{
		e.printStackTrace();
				
		
	}
}
	public static void main(String a[])
	{
		Sel1 s1=new Sel1();
		s1.show();
		
	}

}
