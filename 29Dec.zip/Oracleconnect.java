package orac;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;


public class Oracleconnect {
	
		 public static void main(String ar[]) 
		 
		{
			System.out.println("sjjj");
			System.out.println("........... Oracle JDBC Connection Testing...............");
			Connection connection=null;
			try
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
				connection= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
				System.out.println("Connected");
				}
			catch(Exception e)
			{
				System.out.println("connection fail");
				e.printStackTrace();
				
			}
			
			}
	}


