class Str
{
	public static void main(String ar[])
	{
		String s1="hello";
		String s2="hellos";
		String s3=new String("hellos");
		String s4=new String("hello");
		StringBuffer sb=new StringBuffer("hello world");
		sb=sb.delete(4,8);
		System.out.println("after deteting sb is "+sb);
		sb=sb.append("s");
		System.out.println("After appending sb is "+sb);
		sb=sb.delete(6,11);
		System.out.println("After deleting sb is"+sb);
		//System.out.println(sb==s1);
		System.out.println(sb.equals(s1));
		sb=sb.append("s");
		
		System.out.println(sb.equals(s3));
		//System.out.println(sb==s2);
	}
} 	