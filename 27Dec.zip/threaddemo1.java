class ThreadDemos extends Thread
{
	int i;
	String n;
	ThreadDemos()
	{
		start();
	}
	public void run()
	{
		for(i=0;i<5;i++)
		{
			System.out.println("child thread i="+i);
			System.out.println("child thread "+i+"finished");
		}
	}
}
class Demothread
{
	public static void main(String a[])
	{
		ThreadDemos d=new ThreadDemos();
		ThreadDemos d1=new ThreadDemos();
		
	}
}