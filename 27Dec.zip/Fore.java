class Fore
{
	void dis()
	{
	int x[]={10,11,12};
	for(int i:x)
	{
		System.out.println("i="+i);
	}
	}
	public static void main(String ar[])
	{
		Fore f=new Fore();
		f.dis();
	}
}