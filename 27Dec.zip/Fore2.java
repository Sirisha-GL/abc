class Fore2
{
	void display()
	{
		int x[][]=new int[2][2];
		x[0][0]=1;
		x[0][1]=2;
		x[1][0]=3;
		x[1][1]=4;
		for(int i[]:x)
		{
			for(int q:i)
			System.out.println("q="+q);
		}
	}
	public static void main(String ar[])
	{
		Fore2 f2= new Fore2();
		f2.display();
	}
}