import java.io.*;
class A
{
public static void main(String a[])
{
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
System.out.println("Enter your name:");
System.out.println("Name is " +br.readLine());
}
}
