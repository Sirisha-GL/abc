class Fore1
{
	void dis()
	{
		int i[][]={{10,11},{12,13},{14,15}};
		for(int x[]:i)
		{
			for(int p:x)
			{
				System.out.println("p="+p);
			}
		}
	}
	public static void main(String ar[])
	{
		Fore1 f1= new Fore1();
		f1.dis();
	}
}