class Threads1 implements Runnable
{
	public void run()
	{
		show();
	}
	synchronized void show()
	{
		System.out.println("hello");
	try
	{
		Thread.sleep(1000);
	}
	catch(InterruptedException e)
	{
		System.out.println("child thread interrupted");
	}
	System.out.println("bye");
	}
}
class thread1
{
	public static void main(String arg[])
	{
		Threads1 t=new Threads1();
		Threads1 t1= new Threads1();
		Thread a=new Thread(t);
		Thread a1=new Thread(t1);
		a.start();
		a1.start();
		
	}
}