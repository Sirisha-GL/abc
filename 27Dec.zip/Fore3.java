import java.util.Scanner;
class Fore3
{
	void getval()
	{
		Scanner s= new Scanner(System.in);
		int x[];
		int n;
		System.out.println("number of values in the array n is:");
		n=s.nextInt();
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter the "+i+" th value:");
			x[i]=s.nextInt();
		}
		for(int p:x)
		{
			System.out.println("p="+p);
		}
	}
	public static void main(String a[])
	{
		Fore3 f3= new Fore3();
		f3.getval();
	}
}