import java.io.*;
class FReader
{
static int i;
static FileReader f;
public static void main(String ar[]) throws IOException
{
try
{
f=new FileReader("fine.txt");
}
catch(FileNotFound Exception e)
{
System.out.println("error");
}
do
{
i=f.read();
if(i!=-1)
{
System.out.println((char)i);
}
while(i!=0);
}
}
