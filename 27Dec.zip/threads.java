class runna implements Runnable
{
int i;
String s;
public void run()
{
	for(i=0;i<5;i++)
	{
		System.out.println("this is the child thread "+s+" i+="+i);
		System.out.println("child thread "+s+"finished");
	}

}	
}
class ThreadDemo
{
	public static void main(String Ar[])
	{
		runna r=new runna();
		runna r1=new runna();
		Thread t=new Thread(r);
		Thread t1=new Thread(r1);
		t.start();
		t1.start();
	}
}