class Stringex
{
	public static void main(String ar[])
	{
		String s="hello";
		String s1="hello";
		String s2= new String("hello");
		String s3=new String("hello");
		System.out.println(s.equals(s1));
		System.out.println(s==s1);
		System.out.println(s1==s2);
		System.out.println(s1.equals(s2));
		System.out.println(s2==s3);
		
	}
}