class A 
{
	void s()
	{
		System.out.println("Hello World!");
		try{
			Thread.sleep(1000);
			}
		catch(InterruptedException e)
		{
		System.out.println("Child Thread Interrupted hello");
			}
		System.out.println("Bye World!");
	}
	void s2()
	{
	System.out.println("s2 is being shown");
	}
}
class Syncp implements Runnable{
	int i;
	A a;
	Syncp(A a)
	{
		this.a=a;
	}
	public void run()
	{
		synchronized(a)
		{
			a.s();
		}	
	}
}
class finalp
{
	public static void main (String arg[])
	{
		A a1=new A();
		Syncp d= new Syncp(a1);
		Thread t,t1;
		t=new Thread(d);
		t.start();
		t1=new Thread(d,"two");
		t1.start();
		
	}
}