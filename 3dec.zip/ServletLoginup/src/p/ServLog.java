
package p;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServLog extends HttpServlet {

/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        
        
        try
        {
        	PrintWriter out= response.getWriter();
        	String s=request.getParameter("uname");
        	String s1=request.getParameter("pword");
        	      
        	if(s.equals("abc")&&s1.equals("abc"))
        	{
        	out.println("valid user");
        	out.println("<html><body>");
        	out.println("<form name='ii' method='get' action='pass2'>");
        	out.println("<P>ECODE <input type='text' value='' name='ecode'></P>");
        	out.println("<P>ENAME <input type='text' value='' name='ename'></P>");
        	out.println("<br><input type='submit' value='update' name='click'>");
        	out.println("<br><input type='submit' value='delete' name='click'>");
        	out.println("</form></body></html>");
        	
        	
        	}
        	else
        	{
        		out.print("invalid");
        	}
        }
        

        catch(Exception e)
        {
        e.printStackTrace();
        }
       
       
}
}
