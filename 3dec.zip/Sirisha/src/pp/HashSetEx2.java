package pp;
import java.util.HashSet;
import java.util.Scanner;

class Bookss {
	int id;
	String name, author, publisher;
	int quantity;
	
	public Bookss(int id, String name, String author, String publisher, int quantity)
	{
		this.id = id;
		this.name = name;
		this.author = author;
		this.publisher = publisher;
		this.quantity = quantity;
	}
}

class HashSetEx2
{
	
	void show()
	{
		HashSet<Bookss> set1 = new HashSet<Bookss>();
		
		System.out.println("How many entries of books do you want to enter? ");
		Scanner in = new Scanner(System.in);
		
		int n = in.nextInt();
		
		
		for(int i=0;i<n;i++)
		{
			System.out.println("Id");
			int id1 =in.nextInt();
			in.nextLine();
			
			System.out.println("Enter Name ");
			String name1 =in.nextLine();
			
			
			
			System.out.println("Enter Author");
			String author1 = in.nextLine();
			
			
			System.out.println("Enter publisher");
			String publisher1 = in.nextLine();
			
			System.out.println("Enter quanity");
			int quantity1 = in.nextInt();
			
			
			Bookss b = new Bookss(id1, name1, author1, publisher1, quantity1);
			
			set1.add(b);
			
		
		}
		
		for(Bookss b1 : set1)
		{
			System.out.println(b1.id + " " + b1.name + " " + b1.author + " " + b1.publisher + " " + b1.quantity);
		}
		in.close();
		
		
	}
	public static void main(String args[])
	{
		HashSetEx2 h = new HashSetEx2();
		h.show();
	}
}