package pp;
import java.sql.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Scanner;

public class InseBatch {
void show()
{
	Scanner scan= new Scanner(System.in);
	System.out.println("MySQL Connect Example");
	Connection conn=null;
	String url="jdbc:mysql://localhost:3306/";
	String dbName= "db2";
	String driver="com.mysql.jdbc.Driver";
	String userName="root";
	String password="root";
	try
	{
		Class.forName(driver);
		conn=DriverManager.getConnection(url+dbName,userName,password);
		System.out.println("Enter the number of records to be saved:");
		int n= scan.nextInt();
		
		
		PreparedStatement ps= conn.prepareStatement("insert into emp3 values(?,?)");
	
		conn.setAutoCommit(false);
		for (int m=0;m<n;m++)
		{
				ps.setString(1,scan.next());
		ps.setString(2, scan.next());
		ps.addBatch();
		}
		
		int y[]=ps.executeBatch();
	
		for(int i:y)
		{
			System.out.println(""+i);
			conn.commit();
		
		}
		conn.close();
		System.out.println("disconnected fro db");
		}
	catch(Exception e)
	{
		e.printStackTrace();
				
		
	}
}
	public static void main(String a[])
	{
		InseBatch s1=new InseBatch();
		s1.show();
		
	}

}