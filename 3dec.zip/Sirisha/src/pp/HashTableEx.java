package pp;
import java.util.*;


public class HashTableEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	Hashtable ht = new Hashtable();
	
	ht.put("pop", new Double(543.71));
	ht.put("qad", new Double(837.90));
	ht.put("asdk", new Double(17.99));
	ht.put("kkko", new Double(233.8));
	ht.put("iot", new Double(543.71));
	
	Set set = ht.entrySet();
	
	Iterator i = set.iterator();
	
	while(i.hasNext())
	{
		Map.Entry me = (Map.Entry)i.next();
		System.out.println(me.getKey() + ": ");
		System.out.println(me.getValue());
	}
	System.out.println();

	}

}