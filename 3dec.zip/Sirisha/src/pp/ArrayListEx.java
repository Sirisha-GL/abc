package pp;
import java.util.*;
public class ArrayListEx {
public static void main(String ar[])
{
	ArrayList al=new ArrayList();
	System.out.println("Initial size of the al"+al.size());
	al.add("c");
	al.add("a");
	al.add("b");
	al.add("i");
	al.add("m");
	al.add(3,"c");
	System.out.println("Size of the arraylist after addition is:"+al.size());
	System.out.println("Contents of the array are:"+al);
	al.remove("a");
	al.remove("1");
	System.out.println("Size of the arraylist after deletion is:"+al.size());
	System.out.println("Contents of the array after are deleting:"+al);
	Iterator itr=al.iterator();
	while(itr.hasNext())
	{
		System.out.println(itr.next());
	}
	System.out.println("using foreach loop:");
	for(Object obj:al)
	{
		System.out.println(" "+obj);
	}
	
}
}
