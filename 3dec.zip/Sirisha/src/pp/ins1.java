package pp;
import java.sql.*;
import java.sql.Connection;
import java.sql.ResultSet;

public class ins1 {
void show()
{
	System.out.println("MySQL Connect Example");
	Connection conn=null;
	String url="jdbc:mysql://localhost:3306/";
	String dbName= "db2";
	String driver="com.mysql.jdbc.Driver";
	String userName="root";
	String password="root";
	try
	{
		Class.forName(driver);
		conn=DriverManager.getConnection(url+dbName,userName,password);
		PreparedStatement ps= conn.prepareStatement("insert into emp3 values(?,?)");
		//String s1="tt";
		//String s="e001";
		//ResultSet rs=sm.executeQuery("select * from emp3 where ecode is '"+s+"' and ename is '"+s1+"'");
		ps.setString(1,"e113");
		ps.setString(2,"hhh");
		int x=ps.executeUpdate();
		System.out.println(""+x+"record inserted");
		
		
		//ResultSet rs=sm.executeQuery("select * from emp3");
		System.out.println("connected to the db");
		/*while(rs.next())
		{
			String f=rs.getString(1);
			String f1=rs.getString(2);
			System.out.println(f);
			System.out.println(f1);
		}*/
		conn.close();
		System.out.println("disconnected fro db");
		}
	catch(Exception e)
	{
		e.printStackTrace();
				
		
	}
}
	public static void main(String a[])
	{
		ins1 s1=new ins1();
		s1.show();
		
	}

}

