package pp;
import java.sql.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Scanner;

public class inst {
void show()
{
	Scanner scan= new Scanner(System.in);
	System.out.println("MySQL Connect Example");
	Connection conn=null;
	String url="jdbc:mysql://localhost:3306/";
	String dbName= "db2";
	String driver="com.mysql.jdbc.Driver";
	String userName="root";
	String password="root";
	try
	{
		Class.forName(driver);
		conn=DriverManager.getConnection(url+dbName,userName,password);
		PreparedStatement ps= conn.prepareStatement("update emp3 set ename=? where ecode=?");
		
		ps.setString(1,scan.next());
		ps.setString(2, scan.next());
		
		int x=ps.executeUpdate();
		System.out.println(""+x+"record inserted");
		
		
		//ResultSet rs=sm.executeQuery("select * from emp3");
		System.out.println("connected to the db");
		/*while(rs.next())
		{
			String f=rs.getString(1);
			String f1=rs.getString(2);
			System.out.println(f);
			System.out.println(f1);
		}*/
		conn.close();
		System.out.println("disconnected fro db");
		}
	catch(Exception e)
	{
		e.printStackTrace();
				
		
	}
}
	public static void main(String a[])
	{
		inst s1=new inst();
		s1.show();
		
	}

}