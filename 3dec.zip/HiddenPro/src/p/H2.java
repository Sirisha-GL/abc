package p;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class H2
 */
@WebServlet("/H2")
public class H2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try
		{
			PrintWriter out= response.getWriter();
			String s1=request.getParameter("hid");
			String s2=request.getParameter("hid1");
			out.print("<h1>HELLO "+s1+"</h1><br>");
			out.print("<h1>"+s2+"</h1><br>");
		}
		catch(Exception e)
		{
		}
	
	}

	

}
