package p;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Webapp extends HttpServlet {

protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
Connection conn=null;
String url="jdbc:mysql://localhost:3306/";
String dbName= "db1";
String driver="com.mysql.jdbc.Driver";
String userName="root";
String password="root";
PrintWriter out= response.getWriter();
String s=request.getParameter("ename");
        out.print("s="+s);
        out.print("MySql connect example");
       
       
        try
        {
        Class.forName(driver);
        conn= DriverManager.getConnection(url+dbName,userName,password);
        Statement sm=conn.createStatement();
        ResultSet rs=sm.executeQuery("select * from emp");
        System.out.println("connected to database");
        out.print("<table border=1 bgcolor=lightblue>");
        out.print("<th>ECODE</th><th>ENAME</th>");
        while(rs.next())
        {
        String f=rs.getString(1);
        String f2=rs.getString(2);
        out.print("ename="+f2);
        out.print("<tr><td>"+f+"</td><td>"+f2+"</td></tr>");
        }
        out.println("</table>");
        conn.close();
        out.println("Disconnected from DataBase");
        }
        catch(Exception e)
        {
        e.printStackTrace();
        }
       
       
}
}
