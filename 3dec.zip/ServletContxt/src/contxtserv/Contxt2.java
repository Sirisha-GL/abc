package contxtserv;

import java.io.*;

import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Contxt2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
     ServletContext ctx=null;  
   
    public void init(ServletConfig sc) throws ServletException
    {
       
        ctx=sc.getServletContext(); 
       
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String s=(String)ctx.getAttribute("ob");
		out.println("Hello "+s);
	}

}
