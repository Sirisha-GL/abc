package p;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.*;

public class F1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try
		{
			PrintWriter out=response.getWriter();
			String s=request.getParameter("uname");
        	String s1=request.getParameter("pword");
        	s=s.trim();
        	s1=s1.trim();
        	String t="Siri";
        	out.print("<p></p>"+t);
        	RequestDispatcher rd1=request.getRequestDispatcher("/1");
        	RequestDispatcher rd2=request.getRequestDispatcher("/2");
        	if(s.equals("abc")&&s1.equals("abc"))
        	{
        	out.println("valid user");
        	rd1.include(request,response);
        	}
        	else
        	{
        		out.print("click");
        		rd2.forward(request, response);
        	}
        	}
        	catch(Exception e)
		{}}
		}
	

	