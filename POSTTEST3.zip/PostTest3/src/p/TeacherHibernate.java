package p;

import org.hibernate.Transaction;

import javax.swing.text.html.HTMLDocument.Iterator;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;


public class TeacherHibernate{
	
	public static void main(String Args[])
	{
		Configuration cfg=new Configuration();
		cfg.configure("Hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session ses=sf.openSession();
		Transaction ts=ses.beginTransaction();
		ts.begin();
		Dept d=new Dept();
		d.setTID(7);
		d.setTName("Bag");
		d.setDept("IIT");
		d.setDID(4);
		d.setDname("IIT");
		ses.persist(d);
		Course c=new Course();
		c.setTID(8);
		c.setTName("Cale");
		c.setDept("CIV");
		c.setCID(4);
		c.setCname("Mathematics");
		ses.save(c);
		ts.commit();
	}
}
