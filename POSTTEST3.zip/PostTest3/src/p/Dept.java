package p;

public class Dept extends Teacher{
 private int DID;
 private String Dname;
public int getDID() {
	return DID;
}
public void setDID(int dID) {
	DID = dID;
}
public String getDname() {
	return Dname;
}
public void setDname(String dname) {
	Dname = dname;
}
 
}
