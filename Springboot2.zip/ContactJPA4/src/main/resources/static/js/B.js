$(document).ready(function(){
			 $("button").click(function(){
				$("#pid").hide();
			   });
			});