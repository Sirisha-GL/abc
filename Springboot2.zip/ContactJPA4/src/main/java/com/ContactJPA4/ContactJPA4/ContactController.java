package com.ContactJPA4.ContactJPA4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ContactController 
{
	@Autowired
	ContactService cs;
	
	@RequestMapping("/")
	public String view(Model model)
	{
		List<Contact> lc=cs.listAll();
		model.addAttribute("lstContact",lc);
		
		return "index";
	}
	
	
	@RequestMapping(value="/new")
	public String showNewContactPage(Model model) //for new record
	{
		Contact ct=new Contact();
		model.addAttribute("ContactObj",ct);
		
		return "NewContact";
	}
	
	@RequestMapping(value="/save",method=RequestMethod.POST)//for new record and update
	public String saveNewContact(@ModelAttribute("ContactObj") Contact ContactObj)
	{
		cs.saveContact(ContactObj);
		
		return "redirect:/";
		//return "NewFile";//it's working 
	}
	
	
	@RequestMapping(value="/edit/{id}")
	public ModelAndView showEditContactPage(@PathVariable(name="id") String id) //for edit record
	{
		ModelAndView mv=new ModelAndView("EditContact");
		Contact cnt=cs.getId(id);
		mv.addObject("ContactEditObj",cnt);
		
		return mv;
	}
	
	@RequestMapping(value="/delete/{id}")
	public String DeleteContact(@PathVariable(name="id")String id)
	{
		/*ModelAndView mv =new ModelAndView("DeleteContact");
		Contact cnt=cs.getId(id);
		
		mv.addObject("ContactEditObj")*/
		
		cs.deleteContact(id);
		return"redirect:/";
	}
	
}
